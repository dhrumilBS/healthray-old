<html class="no-js" <?php language_attributes(); ?>>
	<head>
		<?php wp_head(); ?>
	</head>